using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterStore : MonoBehaviour
{
    public static int jetpackCount;
    public static int spacesuitCount;
    // Start is called before the first frame update
   
}
